package common;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

public interface VaultService extends Remote {
    boolean register(String username, String password) throws RemoteException;
    boolean login(String username, String password) throws RemoteException;
    void addPassword(String username, String site, String login, String password) throws RemoteException;
    List<VaultEntry> listPasswords(String username) throws RemoteException;
    List<VaultEntry> searchPasswords(String username, String keyword) throws RemoteException;
}

