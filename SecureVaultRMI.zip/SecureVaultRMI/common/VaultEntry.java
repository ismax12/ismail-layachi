package common;

import java.io.Serializable;

public class VaultEntry implements Serializable {
    private static final long serialVersionUID = 1L;
    private String site;
    private String login;
    private String password;

    public VaultEntry(String site, String login, String password) {
        this.site = site;
        this.login = login;
        this.password = password;
    }

    public String getSite() {
        return site;
    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }
}

