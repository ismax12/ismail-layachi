package server;

import common.VaultEntry;
import common.VaultService;
import util.HashUtil;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class VaultServiceImpl extends UnicastRemoteObject implements VaultService {

    private final Map<String, String> users = new HashMap<>();
    private final Map<String, List<VaultEntry>> passwords = new HashMap<>();

    public VaultServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public boolean register(String username, String password) throws RemoteException {
        if (users.containsKey(username)) return false;
        users.put(username, HashUtil.hash(password));
        passwords.put(username, new ArrayList<>());
        return true;
    }

    @Override
    public boolean login(String username, String password) throws RemoteException {
        String storedHash = users.get(username);
        if (storedHash == null) return false;
        String inputHash = HashUtil.hash(password);
        return storedHash.equals(inputHash);
    }

    @Override
    public void addPassword(String username, String site, String login, String password) throws RemoteException {
        VaultEntry entry = new VaultEntry(site, login, password);
        passwords.get(username).add(entry);
    }

    @Override
    public List<VaultEntry> listPasswords(String username) throws RemoteException {
        return passwords.getOrDefault(username, new ArrayList<>());
    }

    @Override
    public List<VaultEntry> searchPasswords(String username, String keyword) throws RemoteException {
        List<VaultEntry> result = new ArrayList<>();
        List<VaultEntry> entries = passwords.get(username);

        if (entries != null) {
            for (VaultEntry entry : entries) {
                if (entry.getSite().contains(keyword) || entry.getLogin().contains(keyword)) {
                    result.add(entry);
                }
            }
        }

        return result;
    }
}

