package server;

import common.VaultService;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class VaultServer {
    public static void main(String[] args) {
        try {
            // Vérifie si le registre est déjà actif
            try {
                LocateRegistry.createRegistry(1099);
                System.out.println("✅ RMI Registry lancé sur le port 1099...");
            } catch (Exception e) {
                System.out.println("⚠️ RMI Registry déjà actif.");
            }

            VaultService service = new VaultServiceImpl(); // Pas besoin d'exporter manuellement
            Registry registry = LocateRegistry.getRegistry();
            registry.rebind("VaultService", service);

            System.out.println("🔐 SecureVault RMI - Serveur prêt !");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

