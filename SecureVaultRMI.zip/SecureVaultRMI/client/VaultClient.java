package client;

import common.VaultEntry;
import common.VaultService;

import javax.swing.*;
import java.awt.*;
import java.rmi.Naming;
import java.util.List;

public class VaultClient {

    private static VaultService service;
    private static String currentUser = null;

    public static void main(String[] args) {
        try {
            service = (VaultService) Naming.lookup("rmi://localhost/VaultService");
            showLoginUI();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void showLoginUI() {
        JFrame frame = new JFrame("🔐 SecureVault - Connexion");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        JPanel panel = new JPanel(new GridLayout(4, 1));

        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JButton loginBtn = new JButton("Login");
        JButton registerBtn = new JButton("Register");

        panel.add(new JLabel("Nom d'utilisateur:"));
        panel.add(usernameField);
        panel.add(new JLabel("Mot de passe:"));
        panel.add(passwordField);
        panel.add(loginBtn);
        panel.add(registerBtn);

        frame.add(panel);
        frame.setVisible(true);

        loginBtn.addActionListener(e -> {
            try {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (service.login(username, password)) {
                    currentUser = username;
                    frame.dispose();
                    showMainUI();
                } else {
                    JOptionPane.showMessageDialog(frame, "Échec de connexion !");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });

        registerBtn.addActionListener(e -> {
            try {
                String username = usernameField.getText();
                String password = new String(passwordField.getPassword());
                if (service.register(username, password)) {
                    JOptionPane.showMessageDialog(frame, "Inscription réussie !");
                } else {
                    JOptionPane.showMessageDialog(frame, "Nom déjà utilisé.");
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
    }

    private static void showMainUI() {
        JFrame frame = new JFrame("🔐 SecureVault - " + currentUser);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(500, 400);

        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        JTextField siteField = new JTextField();
        JTextField loginField = new JTextField();
        JPasswordField passField = new JPasswordField();
        JTextField searchField = new JTextField();
        JButton addBtn = new JButton("Ajouter");
        JButton listBtn = new JButton("Lister");
        JButton searchBtn = new JButton("Rechercher");
        JTextArea resultArea = new JTextArea();
        resultArea.setEditable(false);

        inputPanel.add(new JLabel("Site:"));
        inputPanel.add(siteField);
        inputPanel.add(new JLabel("Login:"));
        inputPanel.add(loginField);
        inputPanel.add(new JLabel("Password:"));
        inputPanel.add(passField);
        inputPanel.add(new JLabel("🔍 Recherche:"));
        inputPanel.add(searchField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(addBtn);
        buttonPanel.add(listBtn);
        buttonPanel.add(searchBtn);

        frame.setLayout(new BorderLayout());
        frame.add(inputPanel, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.add(new JScrollPane(resultArea), BorderLayout.SOUTH);

        frame.setVisible(true);

        addBtn.addActionListener(e -> {
            try {
                String site = siteField.getText();
                String login = loginField.getText();
                String pass = new String(passField.getPassword());
                service.addPassword(currentUser, site, login, pass);
                JOptionPane.showMessageDialog(frame, "Ajouté !");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Erreur d'ajout.");
            }
        });

        listBtn.addActionListener(e -> {
            try {
                List<VaultEntry> list = service.listPasswords(currentUser);
                resultArea.setText("");
                for (VaultEntry ve : list) {
                    resultArea.append("🔐 " + ve.getSite() + " | " + ve.getLogin() + " | " + ve.getPassword() + "\n");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Erreur de récupération.");
            }
        });

        searchBtn.addActionListener(e -> {
            try {
                String keyword = searchField.getText();
                List<VaultEntry> list = service.searchPasswords(currentUser, keyword);
                resultArea.setText("");
                for (VaultEntry ve : list) {
                    resultArea.append("🔍 " + ve.getSite() + " | " + ve.getLogin() + " | " + ve.getPassword() + "\n");
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(frame, "Erreur de recherche.");
            }
        });
    }
}

