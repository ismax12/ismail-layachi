package server;

import common.VaultService;
import common.VaultEntry;
import util.HashUtil;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

public class VaultServiceImpl extends UnicastRemoteObject implements VaultService {

    private final Map<String, String> users = new HashMap<>();
    private final Map<String, List<VaultEntry>> vaults = new HashMap<>();

    public VaultServiceImpl() throws RemoteException {
        super();
    }

    @Override
    public synchronized boolean register(String username, String password) throws RemoteException {
        if (users.containsKey(username)) return false;
        users.put(username, HashUtil.hash(password));
        vaults.put(username, new ArrayList<>());
        return true;
    }

    @Override
    public synchronized boolean login(String username, String password) throws RemoteException {
        String hash = users.get(username);
        return hash != null && hash.equals(HashUtil.hash(password));
    }

    @Override
    public synchronized void addEntry(String username, String site, String login, String password) throws RemoteException {
        vaults.get(username).add(new VaultEntry(site, login, password));
    }

    @Override
    public synchronized List<VaultEntry> listEntries(String username) throws RemoteException {
        return new ArrayList<>(vaults.get(username));
    }

    @Override
    public synchronized List<VaultEntry> searchEntries(String username, String keyword) throws RemoteException {
        List<VaultEntry> results = new ArrayList<>();
        for (VaultEntry entry : vaults.get(username)) {
            if (entry.site().contains(keyword) || entry.login().contains(keyword)) {
                results.add(entry);
            }
        }
        return results;
    }
}
